GROUPS = [
 dict(id='LEX-A1-01',title='Relações sem presumir uma família',after='A1-01',words=['neighbour','partner','parent','child'],
 situation='A recebe cartão: Lia é parent de uma child chamada Kim; Jo é neighbour de Lia; Rui é partner de Lia numa atividade de estudo. B pergunta quem é cada pessoa com Who is…? e monta uma ficha em português. A apresenta as relações em inglês. Inverta com Eva parent de Sol, Lee neighbour de Eva e Noa partner de Eva no estudo. Não pedir dados familiares reais.',
 result='Lia é mãe/pai de Kim sem gênero definido pelo termo parent; Jo é vizinho/a; Rui é parceiro/a na atividade, sem informação de casamento. Na segunda rodada: Eva/Sol, Lee vizinho/a e Noa parceiro/a de estudo. Modelo: Lia is Kim’s parent. Kim is a child. Jo is Lia’s neighbour. Rui is Lia’s partner in this activity.',
 phon='Ensaie neighbour e partner em frases com nomes. O destinatário deve distinguir a relação; ler silenciosamente não observa produção oral.',
 pitfall='Parent não traduz parente em geral; partner não comprova casamento. Ao recuperar children, distinguir plural irregular de mudança de sentido.'),
 dict(id='LEX-A1-02',title='Profissão, emprego e local de trabalho',after='A1-01',words=['teacher','nurse','driver','work','job'],
 situation='A organiza três fichas: Kim é teacher e works at a school; Jo é nurse e works at a clinic; Eva é driver e works for a bus company. B tem campos name/job/workplace e recolhe informações sem ver as fichas. Acrescente que Kim tem a second job num café e que nada informa gênero das pessoas. Apoios: clinic = clínica; bus company = empresa de ônibus; workplace = local de trabalho; second = segundo. Troquem papéis para conferir as fichas.',
 result='Kim: teacher, escola; segundo emprego num café. Jo: nurse, clínica. Eva: driver, empresa de ônibus. Modelo: Kim is a teacher. Kim works at a school. Kim has a second job at a café. Nurse/driver não fornecem gênero.',
 phon='O ouvinte separa o nome da pessoa e o nome da profissão. Ensaie teacher/nurse/driver com pausas naturais, sem transformar todos os sons em sílabas portuguesas.',
 pitfall='Work pode ser verbo ou nome; aqui as fichas usam work como trabalhar e job como posto contável. Não chamar toda ocupação docente de professor em inglês.'),
 dict(id='LEX-A1-03',title='Organizar o dia sem trocar os horários',after='A1-02',words=['get up','wake up','have breakfast','start','finish','usually'],
 situation='A recebe rotina: wake up 6h; get up 6h30; have breakfast 7h; start work 8h; finish work 16h; usually walk home. B recebe: wake up 7h; get up 8h; have breakfast 8h15; start work 9h; finish work 17h; usually walk home. Perguntem What time do you…? e anotem duas diferenças. Explique a outra dupla em português qual dado é começo do expediente e qual é sair da cama. Apoios: six thirty = 6h30; eight fifteen = 8h15; four/five in the afternoon = 16h/17h.',
 result='A acorda antes de levantar e começa trabalho às 8h; B levanta às 8h e começa às 9h. Usar usually walk home não elimina exceções. Modelo: I wake up at six, but I get up at six thirty. I have breakfast at seven. I start work at eight and finish at four in the afternoon. I usually walk home.',
 phon='Destaque o horário que contrasta, mantendo get up separado de wake up. O interlocutor devolve cada campo, em vez de confirmar tudo com yes.',
 pitfall='Não tratar wake up e get up como sinônimos. Um erro ao converter 16h não é automaticamente erro no significado de finish.'),
 dict(id='LEX-A1-04',title='Entender uma descrição de moradia',after='A1-03',words=['kitchen','bedroom','bathroom','flat','rent'],
 situation='A anuncia: We rent a flat. Two bedrooms, one kitchen, one bathroom. B procura apartamento com dois quartos e pergunta Are there two bedrooms? / Is there a bathroom?. A confirma a composição; B desenha uma planta esquemática e escreve a descrição. Depois troquem com um apartamento de um quarto, uma cozinha e um banheiro. O objetivo é entender o anúncio, não negociar um contrato.',
 result='Primeiro flat: dois bedrooms, uma kitchen e um bathroom; segundo flat: um bedroom. Rent descreve alugar, não comprar. Modelo: We rent a flat. There are two bedrooms. There is a kitchen and a bathroom. Não inferir tamanho, preço ou regras que não aparecem.',
 phon='Ouça bedroom e bathroom e associe ao cômodo correto. Se confundir, confirme a função em português antes de voltar ao inglês.',
 pitfall='Room é genérico; bedroom é quarto de dormir. Não apresentar as descrições fictícias como aconselhamento imobiliário ou características universais de apartamentos.'),
 dict(id='LEX-A1-05',title='Encontrar o serviço certo',after='A1-03',words=['library','bookshop','bus stop','next to','opposite'],
 situation='Desenhe norte [A Library][B Café]; sul [C Bookshop][D Bus stop], com A em frente a C e B em frente a D. A vê o mapa; B recebe grade vazia. A localiza library next to café, bookshop opposite library e bus stop next to bookshop. B coloca etiquetas e escolhe o local indicado por A para comprar um livro. Troquem papéis com library e bookshop trocadas, preservando as relações do novo mapa.',
 result='Primeiro mapa: biblioteca A; livraria C; ponto D. Para compra no cenário, bookshop C. O segundo mapa precisa ser recalculado; não repetir automaticamente a letra C. Modelo: The bookshop is opposite the library. The bus stop is next to the bookshop.',
 phon='Compare library e bookshop em mensagens de destino; a resposta útil é chegar ao serviço certo. Não confiar apenas na semelhança gráfica com livraria.',
 pitfall='Opposite usa lados opostos; next to usa vizinhança. Bus stop não é automaticamente um terminal rodoviário.'),
 dict(id='LEX-A1-06',title='Refeição e preços com critério explícito',after='A1-04',words=['rice','egg','milk','meal','price','cheap','expensive'],
 situation='Planejem a compra fictícia para uma meal: arroz, dois ovos e leite. Loja A: bag of rice 3, egg 1 cada, bottle of milk 2. Loja B: rice 5, egg 2 cada, milk 4. A conhece A, B conhece B. Perguntem price e registrem os dois totais. Para esta personagem, total até 7 é cheap; acima de 9 é expensive. Expliquem qual compra cabe nos 8 créditos disponíveis. O cardápio não é recomendação alimentar.',
 result='Loja A: 3+2+2=7, classificada cheap e cabe em 8. Loja B: 5+4+4=13, expensive segundo o critério fornecido e não cabe. Modelo: We need rice, two eggs and milk for a meal. What is the price? The meal ingredients cost seven credits (os ingredientes custam sete créditos). Usar frase de custo como apoio receptivo, não novo alvo gramatical.',
 phon='Na escuta dos preços, confirmar cada produto e quantidade separadamente. Eggs precisa continuar reconhecível mesmo com pausa antes do número.',
 pitfall='Cheap/expensive dependem do critério; não medir situação econômica real do estudante. Meal não é meat; contar pacotes de rice e garrafas de milk.'),
 dict(id='LEX-A1-07',title='Convidar e escolher uma atividade',after='A1-08',words=['walk','watch','free [gratuito]','free [disponível]','rain','cold','meet','invite'],
 situation='A convida B para uma walk no parque sábado às 10h. A caminhada é free; B está free nesse horário. B informa previsão do cartão: rain e cold. Os dois escolhem watch a film no centro às 10h; ingresso de 2 créditos, portanto não gratuito. Escrevam confirmação de onde vão meet e invite uma terceira pessoa com Would you like to join us?. Não registrem aceitação da terceira pessoa sem resposta. Apoios: community centre = centro comunitário; ticket = ingresso; forecast = previsão; no exercício use It’s going to rain como bloco de apoio.',
 result='Primeiro plano: caminhada gratuita, disponibilidade de B. Plano final: filme no centro, sábado 10h, preço 2; B continua disponível, mas o evento final não é gratuito. Modelo: Are you free on Saturday? Let’s watch a film at the community centre. The film isn’t free. We’re going to meet at ten. Would you like to join us? O convite à terceira pessoa fica sem confirmação.',
 phon='O ouvinte restitui horário, preço e atividade. Free sozinho não basta para dizer se a mensagem trata de preço ou agenda; preserve a frase de contexto.',
 pitfall='Rain/cold são dados fictícios do cartão, não previsão meteorológica atual. Invite não implica confirmação; meet exige encontro, não só envio de mensagem.')
]

GROUPS += [
 dict(id='LEX-A1-08',title='Contar uma rotina e combinar tarefas',after='A1-02',words=['have lunch','have dinner','go to bed','take a shower','cook','clean'],situation='Cartão de Ana: almoço ao meio-dia, jantar às 19h, cama às 22h; banho pela manhã; cozinha sábado, limpa cozinha sexta. Cartão de Rui: almoço às 13h, jantar às 20h, cama às 23h; banho à noite; cozinha sexta, limpa cozinha sábado. Use apoio de horas: twelve = 12h; one = 13h neste contexto; seven = 19h; eight = 20h; ten = 22h; eleven = 23h. Perguntem What time do you have lunch/dinner? e When do you cook/clean? com traduções. Cada um fala com I; destinatário anota três diferenças. Depois combinem quem cozinha sexta e quem limpa sábado sem mudar cartões silenciosamente. Dividir em refeições/horários e ações/dias se necessário.',result='Ana almoça 12h e Rui 13h; jantares 19h/20h; camas 22h/23h. Rui já cozinha sexta e limpa sábado no cartão. Se negociar alteração, confirmá-la explicitamente. Modelo: I have lunch at twelve. I take a shower in the morning. I cook on Saturdays. Rui: I have dinner at eight and go to bed at eleven. Não concluir que quem vai para cama às 23h dorme exatamente às 23h.',phon='O parceiro distingue lunch/dinner e número de hora antes de anotar. Repetição permitida; fornecer twelve/eleven como apoio antes da escuta. Registro de horário por leitura não comprova escuta.',pitfall='Não impor horários ideais de sono/refeição nem solicitar rotina pessoal. Have a shower é alternativa válida a take a shower. Retomar breakfast/get up/wake up sem contabilizá-los como novas entradas. Na produção inicial com I, não exigir terceira pessoa antes de revisar o padrão.'),
 dict(id='LEX-A1-09',title='Ler um anúncio e localizar itens numa moradia',after='A1-03',words=['living room','garden','window','bed','fridge','washing machine'],situation='Dois anúncios fictícios: A, apartamento com sala e quarto; cama no quarto, geladeira e máquina de lavar na cozinha, sem jardim. B, casa com sala e jardim; cama no quarto, geladeira na cozinha, sem máquina de lavar. Nos dois, há cadeira ao lado da janela da sala. A precisa de máquina; B prefere jardim. Distribuam anúncios em cartões separados e perguntem Is there a garden/a washing machine? Where is the bed/fridge? Apoio: sofa = sofá, house = casa, flat = apartamento, no garden = sem jardim. Escolham para a necessidade de cada personagem; não inventem preço ou qualidade.',result='Apartamento A atende necessidade de máquina; casa B tem jardim. The bed is in the bedroom. The fridge is in the kitchen. The chair is next to the window in the living room. There is a washing machine in flat A; there isn’t one in house B. As preferências não tornam uma opção universalmente melhor. O leitor deve localizar objeto e cômodo separadamente.',phon='Contraste bed / bedroom e living room / kitchen em frases. O ouvinte monta tabela Objeto/Cômodo, pedindo repetição. Não exigir definição inglesa de cada objeto antes de usar apoio português.',pitfall='Textos são anúncios fictícios, sem oferta real. Não inferir que casa tem jardim ou que toda cozinha tem máquina. Diferenciar informação ausente de negativa explícita: aqui ausências de jardim/máquina estão declaradas. Retomar mother/father ou outros itens não é necessário para descrever moradia.'),
 dict(id='LEX-A1-10',title='Escolher roupa, confirmar tamanho e perguntar sobre pagamento',after='A1-04',words=['shirt','trousers','shoes','size','try on','pay'],situation='Loja fictícia: camisa azul tamanho M, camisa vermelha tamanho L; calça preta tamanho M; sapatos brancos tamanho 38. Cartão do cliente: quer camisa azul M e experimentar antes de decidir. Vendedor pode oferecer as peças disponíveis; pagamento com cartão é aceito. Apoios: medium = M; large = L; thirty-eight = 38, apenas reconhecimento do cartão; size = tamanho; by card = com cartão. Cliente pergunta Can I try it on?; depois pergunta Can I pay by card? Não realizar compra real. Segunda rodada: cliente quer sapatos e pergunta Can I try them on?; vendedor confirma par e tamanho. Separar experimentação, decisão e pergunta de pagamento.',result='Camisa azul M, não vermelha L. Can I try it on? refere-se à camisa singular; Can I try them on? aos sapatos. What size? — Medium / size M. Can I pay by card? pergunta possibilidade; não significa que pagou ou concluiu compra. These trousers are black e These shoes are white usam plural no bloco fornecido.',phon='Ouça BLUE shirt / RED shirt e M / L com confirmação. Pratique try IT on / try THEM on e peça ao parceiro identificar objeto. Para 38, ler cartão com apoio, sem tratar como domínio de todos os números maiores.',pitfall='Não supor equivalência de tamanhos internacionais. Trousers mantém forma plural no padrão; pants é variante americana válida nesse sentido. Não cobrar tamanho pessoal do aluno, usar personagem. Retomar cores e price/free sem contar como nova aprendizagem lexical completa.'),
 dict(id='LEX-A1-11',title='Conferir transporte e seguir um trajeto curto',after='A1-03',words=['ticket','station','train','bus','turn left','turn right'],situation='Cartões de transporte: Ana vai ao trabalho de trem; Rui vai à escola de ônibus. Ana quer passagem para Central; Rui encontra colega no ponto de ônibus, não na estação. Depois use mapa textual com orientação fixa: “Você sai pela porta da biblioteca olhando para a praça. Virar à sua esquerda leva à estação. Virar à sua direita leva ao ponto de ônibus.” B recebe destino estação; A dá Turn left at the library. Nova rodada destino ponto de ônibus: Turn right at the library. Não mudar orientação inicial. Apoio: ticket = passagem; station = estação; train = trem; bus = ônibus; left = esquerda; right = direita; Central é nome do destino fictício.',result='I go to work by train. I go to school by bus. A ticket to Central, please. Estação e ponto são lugares distintos. Com a orientação dada, esquerda → estação; direita → ponto. O destinatário restitui destino e direção antes de simular movimento. Não inventar horário ou linha de transporte.',phon='Leia left/right em instrução completa e peça ao ouvinte explicar direção em português. Alternar destinos, mantendo orientação explícita. Sem voz, tarefa é leitura de trajeto, não compreensão auditiva.',pitfall='Mapa textual permite trabalho sem imagem; tarefa pode ser feita sem deslocamento corporal. Não exigir navegação real nem conhecimento de cidade. Retomar bus stop, library, at school/at work do percurso anterior. Ticket aqui é transporte e train é substantivo, não outros sentidos.')
]

GROUPS += [{'id': 'LEX-A1-12',
  'title': 'Contar sentimentos e primeiras impressões',
  'after': 'A1-05',
  'words': ['angry', 'worried', 'excited', 'bored', 'friendly', 'shy'],
  'situation': 'Cartões: Ana está preocupada com teste amanhã; Rui animado com passeio sábado; Jo zangado '
               'com barulho agora; Lee entediado na espera. Kim diz “I feel shy with new people”; Nara '
               'cumprimenta cordialmente e oferece ajuda. Em duas rodadas, A representa dois personagens e B '
               'preenche Nome/Como se sente/Motivo informado. Apoio: about = com/em relação a; noise = '
               'barulho; test = teste; trip = passeio/viagem. Depois comparem impressão de Nara (“She seems '
               'friendly”) e declaração de Kim (“Kim says: I feel shy”). Não identificar sentimento só por '
               'silêncio.',
  'result': 'I’m worried about the test. I’m excited about the trip. I’m angry about the noise. I’m bored. '
            'Kim se autodescreve shy; Nara parece friendly pelo comportamento descrito, sem provar amizade '
            'íntima. The wait is boring / I’m bored pode ser usado como contraste com tradução. Motivos não '
            'informados não devem ser inventados.',
  'phon': 'Contraste angry e hungry, retomando pré-A1 com significado antes de ensaio oral. Ouça '
          'bored/boring em frase, marcando pessoa e atividade. Não exigir perfeição sonora para registrar '
          'informação recuperada.',
  'pitfall': 'Some tarefas permitem opinião, outras pedem fonte. Ensinar seems e says como apoios, sem '
             'obrigar nova teoria gramatical. Excited neste uso é expectativa animada. Dividir seis entradas '
             'em três pares se necessário.'}]

GROUPS += [{'id': 'LEX-A1-13',
  'title': 'Relatar bem-estar e localizar uma sensação',
  'after': 'A1-05',
  'words': ['stomach', 'tooth', 'hurt', 'feel well'],
  'situation': 'Cartão Jo: hoje não se sente bem; relata dor na barriga. Cartão Ana: sente-se bem hoje; '
               'ontem teve dor num dente, mas a tarefa focaliza hoje. Cartão Lee: mão não dói; pé dói. '
               'Apoios: I don’t feel well today; My stomach hurts; My tooth hurts; My hand doesn’t hurt; My '
               'foot hurts. A assume personagem e B anota Nome/Bem-estar/Local declarado, usando Is it your '
               'hand? = É sua mão? quando precisa esclarecer. Troquem papéis sem dar conselho de saúde.',
  'result': 'Jo não se sente bem e relata stomach. Ana sente-se bem hoje; não transportar dor passada para '
            'presente. Lee foot hurts, hand doesn’t hurt. Os dados são declarações de personagens; não '
            'inferir causa, gravidade ou tratamento.',
  'phon': 'Contraste hurts / doesn’t hurt e hoje/ontem em contexto. O destinatário aponta rótulo escrito da '
          'parte do corpo, sem depender de gesto ou contato físico.',
  'pitfall': 'Não solicitar sintomas reais nem orientar conduta médica. Stomach é localização leiga aqui. '
             'Teeth pode ser oferecido como apoio, mas singular tooth é alvo produtivo. Aceitar consulta ao '
             'bloco e registrar ajuda.'}]

GROUPS += [{'id': 'LEX-A1-14',
  'title': 'Receber e encaminhar um recado simples',
  'after': 'A1-06',
  'words': ['message', 'send', 'open', 'close'],
  'situation': 'Simulação em papel: envelope “Message from Jo: Meet me on Friday, at ten, Room 4”. Tradução '
               'de Meet me = encontre-me. A manda B abrir cartão com Open the message, please. B lê dia, '
               'hora e sala e confirma. A pede Please send the message to Ana; B move cópia do cartão para '
               'caixa Ana, não Lee. Depois Close the message, please significa dobrar cartão, não rasgar nem '
               'apagar. Nova rodada: mensagem de Rui para Lee, Monday, at ten, Room 5.',
  'result': 'Primeira: origem Jo, destinatária Ana, sexta 10h sala 4. Segunda: origem Rui, destinatário Lee, '
            'segunda 10h sala 5. Open/read/send/close são ações distintas; pedido de envio não conta como '
            'envio até executar movimento do cartão. Close não elimina mensagem.',
  'phon': 'Destinatário recupera FROM Jo / TO Ana e número da sala. Mantenha conteúdo curto e permita '
          'repetição. Sem leitura oral, registrar só recepção escrita e ação.',
  'pitfall': 'Nenhuma conta real é aberta ou mensagem real enviada. Não exigir domínio de interface '
             'tecnológica; cenário de papel verifica língua. Formas de passado não são necessárias para '
             'executar comandos.'}]

GROUPS += [{'id': 'LEX-A1-15',
  'title': 'Combinar atividades de janeiro a junho',
  'after': 'A1-08',
  'words': ['January', 'February', 'March', 'April', 'May', 'June'],
  'situation': 'Calendário fictício com seis meses e tradução. Cartão A: English class starts in January and '
               'ends in June; book club in March; room closed in May. Cartão B: art class in February; '
               'library visit in April; book club note says May. Apoios: starts = começa, ends = termina, '
               'closed = fechado. Troquem informação com When is the book club? / In March. Reparem a nota '
               'incorreta usando March, not May. O destinatário monta quadro mês/atividade e diferencia fim '
               'do curso de fechamento da sala.',
  'result': 'January início do curso; February aula de arte; March clube do livro; April visita; May sala '
            'fechada; June fim do curso. Não inferir que o curso para durante todo maio: falta informação '
            'sobre outro local. Pergunta aceitável: Is there another room in May?',
  'phon': 'Confirmar May/March e June quando o colega não entendeu. Datas permanecem apenas por mês, sem '
          'exigir ordinais ainda não ensinados. Pode haver leitura oral por pessoa de apoio; texto visto '
          'antes limita evidência de escuta.',
  'pitfall': 'Meses são rótulos culturais de calendário, não previsão de clima ou hábitos. Apresentar três '
             'meses por vez, reutilizar o quadro e registrar apoio. Não exigir datas de nascimento.'},
 {'id': 'LEX-A1-16',
  'title': 'Reparar uma agenda de julho a dezembro',
  'after': 'A1-08',
  'words': ['July', 'August', 'September', 'October', 'November', 'December'],
  'situation': 'A recebe: course starts in July; exhibition in September; course ends in November. B recebe: '
               'new room in August; class visit in October; library closed in December. Quadro traduz '
               'exhibition/exposição e os seis meses. Cada participante faz três perguntas When...?; depois '
               'verifica um recado que trocou July por June e October por November. Modelo I have July. Is '
               'that right? = Tenho julho. Está certo? Devolva uma agenda conjunta, preservando eventos '
               'diferentes que ocorrem em meses distintos.',
  'result': 'July início, August nova sala, September exposição, October visita, November fim do curso, '
            'December fechamento da biblioteca. Corrigir June para July; visita não é no mês de '
            'encerramento. Não completar datas exatas ausentes.',
  'phon': 'June/July, September/December e October/November em contexto de atividade. A restituição deve '
          'incluir evento e mês, não só repetir a última palavra ouvida.',
  'pitfall': 'Não associar automaticamente dezembro a férias ou a inverno. O quadro é consulta permitida '
             'durante aprendizagem; na avaliação registrar se foi usado. Integração com janeiro–junho pode '
             'ocorrer em outra sessão, sem apresentação de doze formas de uma só vez.'},
 {'id': 'LEX-A1-17',
  'title': 'Separar duração e horário em uma agenda',
  'after': 'A1-02',
  'words': ['minute', 'hour', 'day', 'week', 'month', 'year'],
  'situation': 'Cartão A: Call: starts at ten, lasts five minutes. Class: starts at two, lasts one hour. '
               'Visit: three days. Cartão B: Course: two weeks. Project: six months. Programme: one year. '
               'Apoios lasts = dura, programme = programa de estudo, at two = às duas. Perguntem How long? = '
               'Quanto tempo? e What time? = A que horas? Complete tabela com início e duração; quando não '
               'existe horário inicial, escreva not given = não informado. Compare one hour com at two para '
               'impedir troca de início e duração.',
  'result': 'Chamada início 10 h/duração 5 min; aula início 2 h/duração 1 h; visita 3 dias, curso 2 semanas, '
            'projeto 6 meses, programa 1 ano, sem horários iniciais informados. Não converter mês '
            'automaticamente em trinta dias nem deduzir datas finais sem calendário e início.',
  'phon': 'O ouvinte repete número e unidade: five MINUTES, one HOUR. Aceitar hour com h não pronunciado e '
          'an hour; corrigir apenas quando troca de unidade altera a informação.',
  'pitfall': 'Apoiar numerais com quadro. Não exigir cálculo de datas ou domínio gramatical de duração até o '
             'presente. O exemplo de year é um programa fictício, não relato biográfico.'}]

GROUPS += [{'id': 'LEX-A1-18',
  'title': 'Pedir esclarecimento e corrigir dados',
  'after': 'A1-08',
  'words': ['could you repeat that',
            'what does it mean',
            'how do you spell',
            'is that right',
            'I mean',
            'please write it down'],
  'situation': 'Cartão A, recepção: nome Lee; room four; Tuesday at ten; closed = fechado. A inicialmente '
               'diz room three e corrige com I mean room four. B precisa preencher nome, sala e horário. B '
               'pede soletração, repetição da hora, significado de closed, confirma a sala e pede o horário '
               'por escrito. A responde L-E-E e fornece os dados do cartão. Inverta com Kim, room two, '
               'Friday at twelve, open = aberto; a correção parte de room one. Autônomo: escreva perguntas '
               'adequadas às seis dificuldades e compare com o retorno; as respostas do outro papel ficam em '
               'cartão separado.',
  'result': 'Ficha 1: Lee, room four, Tuesday at ten; closed significa fechado. Perguntas-modelo: How do you '
            'spell your name? Could you repeat that, please? What does “closed” mean? Room four. Is that '
            'right? Please write it down. A: Room three — I mean room four. Ficha 2: Kim, room two, Friday '
            'at twelve; open = aberto. Registrar o dado corrigido, não os dois como alternativas.',
  'phon': 'Use entonação de pergunta audível em Is that right? e pausa antes da correção I mean. O '
          'destinatário deve recuperar a informação final.',
  'pitfall': 'Repetir som, explicar sentido e soletrar resolvem problemas diferentes. Não avaliar apenas se '
             'a frase foi decorada.'},
 {'id': 'LEX-A1-19',
  'title': 'Organizar uma aula e pedir ajuda para estudar',
  'after': 'A1-08',
  'words': ['lesson', 'homework', 'question', 'answer', 'page', 'practise'],
  'situation': 'A tem recado: English lesson Thursday; homework page twelve, questions one and two; practise '
               'with Jo on Friday. B tem uma anotação incorreta: lesson Tuesday, homework page twenty, '
               'practise alone. Apoio: alone = sozinho. B faz perguntas e registra correções. A não inventa '
               'as respostas do exercício: elas não estão no recado. Troquem usando Monday, page ten, '
               'question three, practise with Kim on Wednesday. Autônomo: escreva um recado de quatro linhas '
               'e uma pergunta sobre informação ausente.',
  'result': 'Primeiro: aula quinta; tarefa página 12, perguntas 1 e 2; prática com Jo sexta. As respostas '
            'das perguntas não foram fornecidas. Modelo: My lesson is on Thursday. The homework is on page '
            'twelve, questions one and two. I practise with Jo on Friday. Can I ask a question? Segundo: '
            'Monday, page ten, question three, Kim on Wednesday.',
  'phon': 'Pratique question e answer em blocos ask a question/write an answer; faça o colega identificar '
          'qual campo deve preencher.',
  'pitfall': 'Não usar homeworks para contar exercícios. Praticar é uma ação; não registrar domínio como '
             'consequência automática.'}]

GROUPS += [{'id': 'LEX-A1-20',
  'title': 'Combinar horas sem trocar o período do dia',
  'after': 'A1-08',
  'words': ["o'clock", 'half past', 'a quarter past', 'a quarter to', 'noon', 'midnight'],
  'situation': 'A tem agenda: lesson 09:00; bus 09:30; lunch 12:00. B tem agenda: meeting 13:15; shop closes '
               '16:45; film ends 00:00 at the end of Saturday. Apoio: lunch = almoço; at the end of Saturday '
               '= no fim do sábado. Troquem horários usando blocos desta aula e confirmem em 24 horas. Uma '
               'terceira mensagem diz midnight Friday sem data: façam pergunta em português ou inglês para '
               'esclarecer a noite antes de registrar. Autônomo: converta os seis horários nas duas direções '
               'e escreva qual dado falta na terceira mensagem.',
  'result': 'Nine o’clock in the morning = 09:00; half past nine in the morning = 09:30; noon = 12:00; a '
            'quarter past one in the afternoon = 13:15; a quarter to five in the afternoon = 16:45; midnight '
            'at the end of Saturday = 00:00 de domingo. Midnight Friday isolado exige confirmação, sem supor '
            'uma das datas. Leituras digitais como nine thirty são aceitas.',
  'phon': 'Diferencie PAST e TO, repita hora e período e peça que o colega escreva o horário. Correção '
          'funcional vale mais que sotaque.',
  'pitfall': 'Half past não significa meia hora antes. A quarter to usa a hora seguinte. Não ensinar 12 '
             'a.m./p.m. sem esclarecer meio-dia/meia-noite.'},
 {'id': 'LEX-A1-21',
  'title': 'Conferir datas e ordem',
  'after': 'A1-08',
  'words': ['first', 'second', 'third', 'twenty-first', 'thirtieth', 'thirty-first'],
  'situation': 'Cartões: first lesson 1 May; second lesson 2 May; third lesson 3 May; visit 21 June; meeting '
               '30 June; party 31 May. Apoio: first/second/third lesson = primeira/segunda/terceira aula; '
               'party = festa. A dita datas com o mês por extenso; B registra em formato dia + nome do mês. '
               'Depois B recebe erro 31 April; calendário de apoio: April 30 days, May 31 days, June 30 '
               'days. B deve pedir correção, não escolher outra data. Autônomo: confira as seis datas e '
               'explique o erro. Datas numéricas como 05/06 exigem perguntar qual convenção foi usada.',
  'result': 'The first/second/third of May; the twenty-first of June; the thirtieth of June; the '
            'thirty-first of May. Aceitar May first etc. O calendário invalida 31 April, sem revelar a data '
            'pretendida. 05/06 pode ser 5 June ou May 6 conforme convenção; escrever mês por extenso após '
            'confirmação.',
  'phon': 'Compare third e thirtieth com número escrito como apoio; o ouvinte confirma 3 versus 30. Não '
          'exigir realização nativa de th para registrar data correta.',
  'pitfall': 'Não interpretar formato de data como universal. Estes seis ordinais não substituem o ensino '
             'posterior dos demais; fornecer tabela quando forem necessários.'}]

GROUPS += [{'id': 'LEX-A1-22',
  'title': 'Ler cardápio e fazer pedido',
  'after': 'A1-04',
  'words': ['vegetable', 'fruit', 'chicken', 'fish', 'sugar', 'salt'],
  'situation': 'Menu fictício: chicken with rice; fish with vegetables; fruit; tea with or without sugar. A '
               'pede fish with vegetables e tea without sugar. Também pergunta se rice without salt está '
               'disponível; atendente B tem resposta no, not today. B confirma pedido e recusa sem mudar o '
               'menu. Troquem com chicken with rice e fruit, perguntando tea without sugar, disponível. '
               'Autônomo: escreva pedido, resposta possível do cartão e lista final separando recusa.',
  'result': 'Primeiro: peixe com vegetais e chá sem açúcar pedidos; arroz sem sal indisponível hoje. '
            'Segundo: frango com arroz, fruta e chá sem açúcar conforme cartão. Pedido não é análise de '
            'ingredientes ou garantia de alergia.',
  'phon': 'Destaque WITHOUT em contrastes with/without; interlocutor deve recuperar omissão solicitada.',
  'pitfall': 'Chicken/fish são alimentos neste uso; não pedir a chicken quando quer porção de carne.'},
 {'id': 'LEX-A1-23',
  'title': 'Comprar e conferir pagamento e troco',
  'after': 'A1-04',
  'words': ['cash', 'card', 'change', 'checkout', 'buy', 'sell'],
  'situation': 'Loja fictícia vende books and pens, não tickets. Placa cash only. Cliente quer buy a book, '
               'price three credits; entrega five credits; conta fornecida five minus three is two. '
               'Atendente orienta checkout e confirma change. Troquem com loja cards accepted, pen two '
               'credits; pagando by card não há troco no cartão do exercício. Autônomo: produza perguntas e '
               'ficha item/preço/meio/troco, sem realizar pagamento.',
  'result': 'Primeiro: livro 3, espécie, entrega 5, troco 2, no caixa; não vende ingresso. Segundo: caneta '
            '2, cartão aceito, sem troco indicado. Can I pay by card? é pergunta, não confirmação de '
            'aceitação.',
  'phon': 'Contraste cash/card e buy/sell em blocos; confirme números antes de encerrar.',
  'pitfall': 'Não coletar cartão real, conta ou recibo real; buy é perspectiva do comprador, sell do '
             'vendedor.'},
 {'id': 'LEX-A1-24',
  'title': 'Interpretar clima em mensagem pessoal',
  'after': 'A1-08',
  'words': ['snow', 'foggy', 'cool', 'umbrella', 'season', 'degree'],
  'situation': 'Mensagem de Kim: It is the rainy season here. It is twenty degrees Celsius. It was foggy '
               'this morning and it is cool this evening. Take an umbrella tomorrow. The photo of snow is '
               'from last year. A explica mensagem em português; B faz três perguntas sobre hoje, amanhã e '
               'foto. Troquem com rainy season, eighteen degrees Celsius, foggy yesterday, cool tonight e '
               'foto sem data; nesse caso a data deve ficar desconhecida. Autônomo: marque o período de cada '
               'afirmação antes de resumir.',
  'result': 'Atual: estação chuvosa, 20°C; neblina de manhã, fresco à noite; levar guarda-chuva amanhã; neve '
            'só em foto do ano passado. Segundo cenário:18°C, neblina ontem; data da foto desconhecida.',
  'phon': 'Destaque today/yesterday/last year e teen/ty em eighteen/twenty; não supor previsão a partir de '
          'foto.',
  'pitfall': 'Não impor hemisfério ou quatro estações universais; não converter Celsius/Fahrenheit sem '
             'apoio.'},
 {'id': 'LEX-A1-25',
  'title': 'Aceitar convite e explicar indisponibilidade',
  'after': 'A1-08',
  'words': ['swim', 'dance', 'sing', 'concert', 'museum', 'weekend'],
  'situation': 'Convites: museum Saturday 10:00, concert Saturday 19:00, dancing Sunday 16:00. Jo likes '
               'music and dancing, is free Saturday evening, busy Sunday. Kim likes swimming and singing, is '
               'free Saturday morning, but there is no swimming event in the list. A recomenda um convite a '
               'Jo com horário; B explica por que não pode prometer atividade preferida a Kim. Depois '
               'escrevam mensagem de 35–50 palavras convidando Jo e pedindo resposta. Autônomo: faça convite '
               'e recusa alternativa com because.',
  'result': 'Jo pode receber convite para concert Saturday at seven in the evening; dancing Sunday conflita '
            'com disponibilidade. Kim pode escolher museu se quiser, mas swimming/singing não estão '
            'oferecidos. Modelo: Would you like to go to the concert on Saturday? It starts at seven. Please '
            'let me know.',
  'phon': 'Confira Saturday/Sunday e horário da noite; destinatário confirma qual evento.',
  'pitfall': 'Gostar de algo não prova que evento existe; convite não confirma participação.'},
 {'id': 'LEX-A1-26',
  'title': 'Ler horários e pedir atendimento',
  'after': 'A1-08',
  'words': ['post office', 'police station', 'opening hours', 'closed', 'form', 'appointment'],
  'situation': 'Mapa: post office next to library; police station opposite park. Aviso fictício do centro '
               'comunitário: opening hours Monday–Friday 09:00–17:00; closed Saturday and Sunday; '
               'appointments by request; fill in a form. A quer atendimento Saturday; B explica horário e '
               'pede formulário com nome fictício, sem confirmar data. Troquem com pedido Tuesday morning; é '
               'dentro do funcionamento, mas horário individual ainda precisa confirmação. Autônomo: escreva '
               'mensagem pedindo appointment e indicando uma disponibilidade.',
  'result': 'Correio ao lado da biblioteca; posto policial em frente ao parque. Sábado fechado. Terça de '
            'manhã é possível disponibilidade, não appointment confirmado. Modelo: Could I make an '
            'appointment? I am free on Tuesday morning. Is there a form?',
  'phon': 'Pratique fourteen/four e horários com confirmação escrita quando necessário; foco na informação '
          'disponível.',
  'pitfall': 'Horário de funcionamento não equivale a agendamento; não inventar documentos ou regras reais '
             'de serviço.'}]
