# LEX-A1-14 — condução

[Aluno](student.md) · [Retomada](review.md) · [Avaliação](assessment.md) · [Respostas](feedback.md)

Pré-requisito: A1-06. Trabalhe apenas este conjunto antes de abrir outro. Apresente cada sentido com os exemplos e objetos/cartões correspondentes. Peça a prática; corrija sem antecipar avaliação. Distribua os cartões da situação de uso em papéis separados; quem recebe a mensagem não deve ver o cartão do colega. Inverta os papéis. Registre dados efetivamente recuperados.

Nenhuma conta real é aberta ou mensagem real enviada. Não exigir domínio de interface tecnológica; cenário de papel verifica língua. Formas de passado não são necessárias para executar comandos.

## Retomada e avaliação

A retomada ocorre no início do encontro seguinte, antes de consultar exemplos. A avaliação ocorre em sessão posterior à retomada, com os novos dados impressos. Anote datas reais; nenhuma ocorrência é inferida da presença do arquivo. Um acerto isolado não estabelece domínio durável.

Para as situações orais, distribua os dados do cenário em cartões separados. O destinatário deve registrar o que entendeu; pode pedir repetição. Não leia o gabarito como estímulo. Atividades escritas não são reclassificadas como escuta.

## Modalidade autônoma

O estudante segue instruções e respostas do pacote. Uma pessoa de apoio pode ler os trechos e atuar como destinatário sem ensinar; registre sua participação. Sem parceiro, as tarefas de interação são ensaiadas e ficam pendentes de observação. Não exigir que o estudante veja um roteiro reservado para fingir compreensão auditiva.

## Evidência

Por palavra: tarefa; data; resposta inicial; ajuda; canal observado; correção; próxima retomada. Em tarefas abertas, verifique se o destinatário recebeu a informação pretendida. Aceite alternativas naturais e registre quando a expressão-alvo não foi observada. Autoria concluída para este núcleo; suficiência lexical do nível, revisão independente e pilotagem continuam abertas.
