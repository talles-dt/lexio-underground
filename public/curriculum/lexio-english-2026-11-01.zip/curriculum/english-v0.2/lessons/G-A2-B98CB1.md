# G-A2-B98CB1 — Conselho, obrigação e proibição

Faixa proposta: **A2** · família: modality · modalidade-alvo: produtiva.

Estado: microaula autoral, não pilotada. Esta microaula é um recurso de ensino e prática, **não uma unidade comunicativa completa nem evidência de suficiência**. [Critérios](../ACCEPTANCE.md).

Pré-requisitos propostos: [G-A1-FFA2AE](G-A1-FFA2AE.md)

## Introdução — I

**O que a forma permite:** Should aconselha; must/have to obriga; mustn’t proíbe; don’t have to dispensa.

**Exemplo:** You mustn’t park here. You don’t have to pay.

**Contraste a observar:** Dispensa não significa proibição.

Leia o exemplo, identifique a informação comunicada e compare com o contraste. Se uma palavra desconhecida impedir o entendimento, esclareça-a antes da prática; não atribuir erro gramatical a falta de vocabulário.

## Compreensão e prática — P

Qual proíbe entrada: You mustn’t enter / You don’t have to enter?

Tente sem abrir a resposta. Depois explique qual informação a forma escolhida preserva. Faça uma segunda tentativa se a primeira foi cópia do exemplo.

<details><summary>Resposta comentada</summary>

You mustn’t enter.

</details>

## Produção orientada — U

Escreva aviso com regra obrigatória, item opcional e conselho.

Antes de produzir, decida quem fala, para quem e com que finalidade. No pré-A1, use cartão e blocos. A partir de A1, produza a mensagem mínima que realiza a ação; nos níveis altos, acrescente contexto suficiente para tornar a escolha linguística necessária. Não adicionar estruturas complexas sem função.

**Modelo linguístico de apoio:** You mustn’t park here. You don’t have to pay.

O modelo mostra a estrutura, não é uma resposta completa a toda a situação de transferência. Verifique o contraste acima ao adaptar sua produção. Correção humana ainda é necessária para avaliar usos abertos não previstos.

## Retomada posterior — R

Em outro encontro, cubra a explicação e leia apenas a tarefa de produção. Mude o referente e o destinatário: por exemplo, de você para um personagem e de conversa para bilhete. Refaça a mensagem e explique o que precisou mudar. Preserve o contraste: Dispensa não significa proibição.

O intervalo e a presença real dessa revisão no curso precisam constar no registro de execução; ter este roteiro escrito não prova que houve revisão espaçada.

## Transferência e avaliação — A

Faça a mesma ação com um dado não usado no exemplo. O parceiro recebe somente a mensagem e restitui o que entendeu. Compare com sua intenção. Sem parceiro, registre autoavaliação de produção e mantenha interação não observada.

Critérios locais: (1) o sentido pretendido foi preservado; (2) a forma serve à função; (3) o contraste não foi invertido; (4) o destinatário consegue recuperar informação essencial. Registre apoio necessário. Não somar estes critérios para produzir nota CEFR.

**Checagem do contraste:** explique por que a forma do exercício resolve o problema: You mustn’t enter.

Esta avaliação aberta é uma especificação com critérios. Não é item independente calibrado: o aluno já conhece exercício e resposta. Uma avaliação de saída deve usar fonte e situação inéditas.

## Percursos

**Autônomo:** leia I, tente P, confira a resposta, faça U, guarde primeira versão e programe R. Em A, use os quatro critérios e registre ausência de interlocutor quando aplicável.

**Com professor:** modele I, peça a explicação do contraste antes da regra, observe P, distribua destinatários diferentes em U e guarde um exemplo anônimo para retomar em R. Em A, acrescente pergunta de seguimento e registre o efeito do apoio.

## Componentes e recuperação

Syntaxis trabalha forma e sentido; Pulse recupera o contraste; Palácio guarda exemplo com contexto; Shadow usa a mensagem em troca; Phonos verifica que a diferença importante é audível. Nem toda microaula requer sessão separada de cada componente.

Se P falhar, retome o exemplo e peça seleção entre as duas interpretações do contraste. Se U falhar, reduza a mensagem a uma informação e ofereça início de frase. Se R falhar, aumentar apoio e repetir depois com dado diferente. Uma tentativa correta isolada não encerra o item.
