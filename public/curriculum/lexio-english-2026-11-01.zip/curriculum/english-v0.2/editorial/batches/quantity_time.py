"""Authored 2026-11-01: numeracy and temporal language, not an automatic word list."""
BLOCKS = {
('pre-a1','numbers'): '''eleven|onze|eleven + plural|Eleven pens.|11; não confundir com o código 1–1, one one.|Cartão Quantity: 11. Escolha eleven ou one.|Eleven.|Etiqueta 11 books: quantos livros?|Onze livros.|Pedido eleven cups: selecione caixa 11 ou 1.|Caixa 11.
twelve|doze|twelve + plural|Twelve cups.|12; valor diferente de twenty, 20.|Ligue twelve à etiqueta 12 ou 20.|12.|Pedido: twelve pens. Escreva o número.|12.|Caixa com 12 livros: complete ___ books com twelve ou two.|Twelve books.
thirteen|treze|thirteen + plural|Thirteen books.|13; contraste com thirty, 30, será retomado em outra sequência.|Quantidade 13: escolha thirteen ou three.|Thirteen.|Quantos itens em thirteen cups?|13.|B tem caixas 13 e 30. A pede thirteen pens. Qual caixa?|13.
fourteen|quatorze|fourteen + plural|Fourteen chairs.|14; a terminação teen precisa permanecer recuperável.|Escreva em algarismos fourteen.|14.|Etiqueta 14 chairs: selecione four ou fourteen.|Fourteen.|A recebe pedido fourteen cups; B oferece 4. Aceitar ou corrigir?|Corrigir para 14; Fourteen, please.
fifteen|quinze|fifteen + plural|Fifteen pens.|15; não fiveteen. Comparar fifty em rodada posterior.|Pedido fifteen books: escolha 5 ou 15.|15.|Cartão 15 cups: complete com fifteen ou five.|Fifteen cups.|Recepção precisa de 15 cadeiras. Diga a quantidade com apoio fifteen.|Fifteen chairs, please.
sixteen|dezesseis|sixteen + plural|Sixteen cups.|16; confirme quantidade, não apenas a presença de six.|Traduza sixteen para algarismos.|16.|Selecione etiqueta sixteen para 6 ou 16.|16.|Pedido 16 pens; resposta Six? Corrija com bloco disponível.|Sixteen, please.
seventeen|dezessete|seventeen + plural|Seventeen chairs.|17; grafia seventeenth não pertence a esta tarefa.|Cartão 17: selecione seventeen ou seven.|Seventeen.|Quantos livros em seventeen books?|17.|Caixas 7 e 17. Pedido seventeen cups: selecione a correta.|17.
eighteen|dezoito|eighteen + plural|Eighteen pens.|18; grafia eighteen, com apenas um t entre eight e een.|Pedido eighteen chairs: escolha 8 ou 18.|18.|Cartão 18 cups: leia com apoio eighteen.|Eighteen cups.|A dita eighteen books; B anota 80. Confirme o valor correto em algarismos.|18.
nineteen|dezenove|nineteen + plural|Nineteen books.|19; contraste com ninety, 90, na próxima sequência.|Ligue nineteen a 19 ou 9.|19.|Quantas cadeiras: nineteen chairs?|19.|Duas etiquetas 19 e 90. Selecione nineteen pens.|19.
twenty|vinte|twenty + plural|Twenty cups.|20; two é 2, twelve é 12.|Etiqueta 20: selecione twelve ou twenty.|Twenty.|Pedido twenty pens: escreva a quantidade.|20.|Recepção oferece 12 livros, pedido 20. Corrija com apoio twenty.|Twenty books, please.
thirty|trinta|thirty + plural|Thirty chairs.|30; contrasta com thirteen, 13. Confirmação numérica é permitida.|Escolha 13 ou 30 para thirty.|30.|Etiqueta 30 books: escreva thirty ou thirteen.|Thirty.|Pedido thirty cups; resposta Thirteen? Corrija usando palavra e algarismo.|Thirty: 30.
forty|quarenta|forty + plural|Forty pens.|40; grafia forty, não fourty.|Ligue forty ao número 40 ou 14.|40.|Complete Forty chairs = ___ cadeiras.|40.|Cartão 40 cups: selecione forty ou fourteen.|Forty.
fifty|cinquenta|fifty + plural|Fifty chairs.|50; contraste fifteen, 15; contexto e confirmação importam.|Pedido fifty cups: escolha 15 ou 50.|50.|Escreva em algarismos fifty pens.|50.|A pede 50 livros; B confirma Fifteen? Responda com fifty.|Fifty books, please.
sixty|sessenta|sixty + plural|Sixty books.|60; não sixteen, 16.|Ligue sixty à etiqueta 60 ou 16.|60.|Pedido sixty chairs: quantas?|60.|Cartão 60 cups: selecione sixteen ou sixty e confirme número.|Sixty, 60.
seventy|setenta|seventy + plural|Seventy cups.|70; contraste seventeen, 17.|Selecione 17 ou 70 para seventy.|70.|Quantos livros em seventy books?|70.|Pedido 70 pens; escreva bloco usando seventy.|Seventy pens, please.
eighty|oitenta|eighty + plural|Eighty pens.|80; grafia eighty; eighteen é 18.|Etiqueta 80: selecione eighteen ou eighty.|Eighty.|Eighty chairs corresponde a 18 ou 80?|80.|Caixa 18 e caixa 80; entregue eighty cups.|Caixa 80.
ninety|noventa|ninety + plural|Ninety chairs.|90; grafia ninety; nineteen é 19.|Ligue ninety a 19 ou 90.|90.|Escreva a quantidade de ninety books.|90.|Pedido 90 cups; B anota 19. Corrija com ninety.|Ninety cups: 90.
one hundred|cem|one hundred + plural|One hundred cups.|100; hundred não recebe s após número exato: one hundred cups.|Selecione 10 ou 100 para one hundred.|100.|One hundred pens: qual quantidade?|100.|Cartão 100 chairs: diga o pedido com apoio one hundred.|One hundred chairs, please.''',
('a1','time'): '''January|janeiro|in January|The course starts in January.|Meses com inicial maiúscula; in para mês sem dia.|Calendário bilíngue January = janeiro. Quando começa o curso do exemplo?|Em janeiro.|Encontro em janeiro: complete in ___.|In January.|Cartão: Library opens in January. A biblioteca abre em março ou janeiro?|Janeiro.
February|fevereiro|in February|My class starts in February.|Não exigir memorização de quantos dias tem o mês; fornecer calendário.|Agenda: English in February. Selecione fevereiro ou abril.|Fevereiro.|Traduza a etiqueta fevereiro usando February.|February.|Convite diz in February; colega marca January. Corrija com bloco.|It is in February, not January.
March|março|in March|We meet in March.|March é mês aqui; march também pode ter outro sentido, não avaliado.|Calendário: March = março. Em qual mês ocorre o encontro?|Março.|Complete reunião em março: We meet in ___.|March.|Aviso: The class is in March, not May. Qual mês vale?|Março.
April|abril|in April|The shop opens in April.|Não confundir April/abril com August/agosto.|Associe April a abril ou agosto.|Abril.|Agenda em abril: complete in ___.|April.|A visita é in April; uma pessoa anotou August. Corrija o mês.|The visit is in April.
May|maio|in May|My friend visits in May.|Inicial maiúscula distingue o nome do mês na escrita; may modal é outro uso.|Selecione maio ou março para May.|Maio.|Plano em maio: escreva in May ou in March.|In May.|Cartão: We meet in May. Diga o mês em português.|Maio.
June|junho|in June|The course ends in June.|June/junho e July/julho devem ser conferidos separadamente.|Curso termina in June. Junho ou julho?|Junho.|Escreva a etiqueta junho com apoio June.|June.|Mensagem June, not July. Em qual mês marcar a data?|Junho.
July|julho|in July|We visit Ana in July.|July/julho não June/junho; confirmar oralmente se necessário.|Visita in July: selecione julho ou junho.|Julho.|Complete viagem em julho: in ___.|July.|Agenda diz July; colega lê June. Corrija com frase-modelo.|It is in July, not June.
August|agosto|in August|My classes start in August.|Sílaba inicial é normalmente tônica no nome do mês; não avaliar sotaque.|Associe August a agosto ou abril.|Agosto.|Cartão agosto: escreva August ou April.|August.|The room is available in August. Quando há disponibilidade?|Em agosto.
September|setembro|in September|The exhibition opens in September.|Exhibition = exposição, apoio fornecido; início maiúsculo.|Aviso: September = setembro. Quando abre a exposição?|Setembro.|Encontro em setembro: complete in ___.|September.|Reserva diz in September; outra diz in October. Qual corresponde a setembro?|In September.
October|outubro|in October|We have a meeting in October.|Meeting = reunião; não requer conhecer feriados estrangeiros.|Selecione outubro ou novembro para October.|Outubro.|Agenda outubro: escreva October.|October.|Mensagem: October, not November. Qual mês deve constar no bilhete?|Outubro.
November|novembro|in November|The course begins in November.|Begins = começa; apoio, não novo alvo avaliado.|Associe November a novembro ou setembro.|Novembro.|Complete em novembro: in ___.|November.|Two visits: October and November. Qual é em novembro?|A visita marcada November.
December|dezembro|in December|The library closes in December.|Não inferir festas, férias ou clima a partir do mês.|Biblioteca closes in December. Em qual mês fecha?|Dezembro.|Encontro dezembro: escreva in December.|In December.|Agenda: opens in November, closes in December. Quando fecha?|Em dezembro; não novembro.
minute|minuto como unidade de duração|ten minutes|The call is ten minutes long.|Número maior que um usa minutes; não confundir duração com hora de início.|Chamada de ten minutes: duração de dez minutos ou dez horas?|Dez minutos.|Conversa dura five minutes. Quantos minutos?|Cinco.|Cartão duração 20 minutos: complete twenty ___.|Twenty minutes.
hour|hora como unidade de duração|one hour; two hours|The class lasts one hour.|An hour usa an porque h não é pronunciado no uso padrão.|One hour: uma hora ou um dia?|Uma hora.|Aula two hours long. Duração em português?|Duas horas.|Filme dura one hour, começa às três. Ele dura três horas?|Não; dura uma hora. Três é o início.
day|dia como unidade e período|one day; three days|I work three days a week.|Day aqui não significa necessariamente período contínuo de 24h de trabalho.|Three days a week: três dias ou três semanas?|Três dias por semana.|Viagem two days long. Duração em dias?|Dois dias.|Cartão: one day at school. Complete com day ou year.|One day.
week|semana como período|one week; two weeks|The course lasts two weeks.|A semana tem sete dias; não confundir weekdays com a semana inteira.|Two weeks: duas semanas ou dois meses?|Duas semanas.|Reserva one week: quantas semanas?|Uma.|Viagem dura three weeks. Copie só a duração em inglês.|Three weeks.
month|mês como período|one month; six months|I study for six months.|Meses não têm todos o mesmo número de dias; não converter automaticamente em 30.|Six months: seis meses ou seis minutos?|Seis meses.|Curso one month long. Qual a unidade?|Mês.|Estadia dura two months. A frase diz duas semanas?|Não; dois meses.
year|ano como período|one year; two years|The programme lasts one year.|Programme/program são grafias aceitas; aqui é duração planejada de um programa.|Two years: dois anos ou dois dias?|Dois anos.|Programa one year long. Quanto dura?|Um ano.|Cartão: duration 3 years. Escreva three ___.|Three years.''',
('a2','time'): '''once|uma vez em determinada frequência|once a week|We meet once a week.|Once aqui é frequência; não o conectivo once = assim que.|Há um encontro por semana. Complete ___ a week.|Once.|A library visit once a month: quantas visitas mensais?|Uma.|Duas visitas por mês: once a month descreve corretamente?|Não; twice a month.
twice|duas vezes em determinada frequência|twice a month|She calls twice a month.|Não significa two months; distinguir frequência e duração.|Duas chamadas em cada mês: escolha twice a month ou for two months.|Twice a month.|Twice a week: quantas vezes por semana?|Duas.|Agenda com duas aulas por semana. Escreva uma frase com twice.|There are classes twice a week.
daily|diariamente|a daily update; update daily|The notice is updated daily.|A atualização pode acontecer em horários diferentes; daily não fixa a hora.|Aviso é atualizado todos os dias. Escolha daily ou monthly.|Daily.|A daily message chega a cada dia ou a cada mês?|A cada dia.|Texto: We check the list daily. Ele informa horário exato?|Não; informa frequência diária.
weekly|semanalmente ou semanal|a weekly meeting; meet weekly|There is a weekly meeting.|Não significa todo dia útil; o dia da semana pode não estar declarado.|Uma reunião a cada semana: daily ou weekly?|Weekly.|Weekly classes: o texto diz qual dia da semana?|Não.|Agenda tem reunião às sextas toda semana. Descreva com weekly.|There is a weekly meeting on Fridays.
monthly|mensalmente ou mensal|a monthly report|We send a monthly report.|Monthly não garante intervalo de exatamente 30 dias.|Relatório de cada mês: escolha monthly ou weekly.|Monthly.|A monthly call: frequência mensal ou duração de um mês?|Frequência mensal.|Mensagem: monthly, on the first Monday. Ela pode ocorrer em datas diferentes de cada mês?|Sim; primeira segunda-feira, não data fixa.
every other day|dia sim, dia não|every other day|We practise every other day.|Distinguir every day. Na tarefa, fornecer data de início.|Prática segunda, quarta, sexta. Every day ou every other day?|Every other day.|Começa terça; every other day. Próximo dia?|Quinta-feira.|Início dia 10; prática dia sim, dia não. Escolha dias 10, 11, 12 ou 10, 12, 14.|10, 12, 14.''',
('a2','numbers'): '''litre|litro como unidade de volume|a litre of water; two litres|We need two litres of water.|Litre/liter são grafias britânica/americana; ambas aceitas.|Pedido 2 L de água: complete two ___ of water.|Litres; liters também aceito.|One litre of juice: qual unidade?|Litro de volume.|Lista: 3 L milk. Escreva a quantidade com litre/liter.|Three litres of milk; three liters of milk.
kilogram|quilograma como unidade de massa|a kilogram of rice|The bag contains one kilogram of rice.|Kilo é forma corrente; kg é símbolo, sem plural s.|Saco 1 kg: one kilogram ou one litre of rice?|One kilogram of rice.|Two kilograms of apples: medida de massa ou distância?|Massa.|Lista: 4 kg rice. Escreva four ___ of rice.|Four kilograms of rice; four kilos of rice.
metre|metro como unidade de comprimento|two metres long|The table is two metres long.|Metre/meter são grafias de variedades; unidade não é metro de transporte.|Mesa 2 m: two metres long ou two litres long?|Two metres long.|Three meters: comprimento ou volume?|Comprimento.|Fita 5 m: escreva five metres ou five meters.|Ambas as grafias são aceitas.
half|metade de uma quantidade|half a litre; half of the group|Half of the ten cards are blue.|Plural halves; half aqui quantidade, não julgamento aproximado.|Dez cartões, metade azul. Quantos azuis?|Cinco.|Half a litre: metade de um litro ou dois litros?|Metade de um litro.|Oito pessoas; metade vem hoje. Complete ___ of the group e diga quantas.|Half of the group; quatro.
quarter|um quarto de uma quantidade|a quarter of the class|A quarter of the twelve chairs are red.|Quarter também aparece em horários e moedas; esses sentidos exigem contexto próprio.|Doze cadeiras; um quarto vermelho. Quantas?|Três.|A quarter of eight cards: quantos?|Dois.|Vinte convites; cinco respondidos. Descreva fração com quarter.|A quarter of the invitations have replies; cinco de vinte.
dozen|grupo de doze unidades|a dozen eggs; two dozen|We ordered a dozen cups.|Número exato: two dozen cups, sem s em dozen; dozens of indica quantidade vaga.|A dozen cups: 10 ou 12?|12.|Two dozen pens: 24 ou 20?|24.|Pedido 12 cadeiras. Escreva com a dozen.|A dozen chairs.''',
('b1','numbers'): '''estimate|estimativa ou estimar|estimate the cost; an estimate|Our estimate is about fifty people.|Estimativa não é contagem confirmada; indicar fonte e momento.|There may be 50 guests. Transforme em estimate sem confirmar presença.|Our estimate is about fifty guests.|Estimate 80; confirmed 62. Qual número é confirmado?|62; 80 é estimativa.|Redija nota: previsão de 40 visitantes, 27 inscrições confirmadas.|We estimate forty visitors; twenty-seven have registered. Não igualar as duas contagens.
approximately|aproximadamente|approximately thirty minutes|The journey takes approximately thirty minutes.|Não determina tolerância matemática universal.|Viagem cerca de 45 minutos. Reescreva com approximately.|The journey takes approximately forty-five minutes.|Approximately 20: a frase garante exatamente vinte?|Não.|Contagem ainda incompleta sugere 70 pessoas. Use approximately e indique incerteza.|Approximately seventy people; the count is not complete.
at least|pelo menos, limite inferior inclusivo|at least ten|We need at least ten chairs.|Dez atende a at least ten; nove não. Não confundir com no máximo.|Mínimo 12 cadeiras; 12 atende a at least twelve?|Sim.|At least 8: 7, 8 e 10; quais atendem?|8 e 10.|Há 15 inscritos confirmados e mais podem vir. Use at least sem inventar máximo.|At least fifteen people have registered; mais podem se inscrever.
at most|no máximo, limite superior inclusivo|at most twenty|The room can take at most twenty people.|Limite linguístico do cartão; não é avaliação real de ocupação segura.|At most 10: onze está permitido no cartão?|Não.|At most 12: quais atendem, 11, 12, 13?|11 e 12.|Regra fictícia aceita até cinco textos. Escreva com at most.|You can submit at most five texts.
up to|até um limite, conforme contexto|up to thirty participants|The workshop has space for up to thirty participants.|Capacidade máxima não é comparecimento nem garantia de lotação.|Up to 30 participants. Isso prova que trinta vieram?|Não.|Up to five pages: seis páginas atende?|Não.|Cartão diz capacidade 20; inscritos 14. Relate os dois sem confundir.|There is space for up to twenty participants; fourteen have registered.
no more than|não mais que, limite superior|no more than three|Use no more than three examples.|No more than pode minimizar em outros contextos; aqui é limite de instrução.|Instrução no more than 3 examples: quatro atende?|Não.|No more than ten minutes: dez atende ao limite?|Sim.|Tarefa permite de zero a dois anexos. Escreva limite com no more than.|Use no more than two attachments.''',
('b1','time'): '''postpone|adiar para momento posterior|postpone the meeting until Friday|They postponed the meeting until Friday.|Não equivale a cancelamento definitivo; o novo momento pode estar ausente.|Reunião terça passa a quinta. Use postpone.|They postponed the meeting until Thursday.|Postponed, new date unknown: sabemos a nova data?|Não.|Evento sexta passa à próxima segunda. Escreva aviso claro.|The event has been postponed until Monday. Não dizer cancelled.
bring forward|antecipar um compromisso|bring the meeting forward to Monday|They brought the meeting forward from Thursday to Monday.|No contexto da agenda, mover para antes; explicitar datas evita ambiguidade.|Agenda quarta passa a segunda da mesma semana. Use bring forward.|The meeting was brought forward to Monday.|Brought forward from Friday to Wednesday: mais cedo ou mais tarde?|Mais cedo.|Reunião dia 18 passa para dia 16 do mesmo mês. Escreva ambas as datas.|The meeting was brought forward from the eighteenth to the sixteenth.
run late|estar atrasado em relação ao previsto|run ten minutes late|The class is running ten minutes late.|Relato de atraso não informa automaticamente novo horário final.|Aula prevista 10h inicia 10h10. Use run late.|The class is running ten minutes late.|Running late: isso significa aula cancelada?|Não.|Ônibus está 15 minutos atrasado, chegada exata desconhecida. Faça aviso.|The bus is running fifteen minutes late; the exact arrival time is not confirmed.
in the meantime|nesse intervalo, enquanto se espera|in the meantime, + clause|The room opens at two. In the meantime, wait here.|Conecta ação durante espera; não substitui ultimately/eventually.|Sala abre às 14h; podemos ler agora. Conecte com in the meantime.|The room opens at two. In the meantime, we can read.|Há uma resposta pendente. In the meantime, check the list. Quando conferir?|Enquanto a resposta não chega.|Entrega foi adiada. Podemos preparar as etiquetas enquanto esperamos. Escreva ligação.|The delivery has been postponed. In the meantime, we can prepare the labels.
eventually|por fim, depois de algum tempo|eventually + verb|After three attempts, we eventually found the room.|Falso cognato: não significa ocasionalmente neste uso.|Após várias tentativas, encontraram o livro. Use eventually.|They eventually found the book.|Eventually arrived: chegada aconteceu às vezes ou por fim?|Por fim.|Depois de duas revisões, o grupo concordou. Redija com eventually.|After two revisions, the group eventually agreed.
overtime|tempo de trabalho além do horário normal|work overtime|They worked overtime to finish the task.|Não presumir remuneração ou obrigação; isso depende de informações não fornecidas.|Equipe trabalhou além do horário. Complete worked ___.|Overtime.|Worked overtime: a frase prova pagamento extra?|Não.|Relato diz duas horas extras, nada sobre pagamento. Faça síntese fiel.|They worked two hours of overtime; the report does not say whether it was paid.''',
('b2','numbers'): '''ratio|razão entre duas quantidades|a ratio of two to one|The ratio of blue cards to red cards is two to one.|Ordem importa: azul:vermelho não é vermelho:azul; fornecer contagens.|12 cartões azuis, 6 vermelhos. Razão azul:vermelho?|Two to one, 2:1.|6 azuis e 12 vermelhos. Mesma razão anterior?|Não; azul:vermelho 1:2.|Sala A tem 9 adultos e 3 crianças. Expresse a razão adulto:criança sem juízo de valor.|The ratio of adults to children is three to one.
proportion|parcela em relação ao total|the proportion of respondents|The proportion choosing A was six out of ten.|Denominador é o grupo definido; não generalizar para população não observada.|6 de 10 respondentes escolhem A. Descreva proportion.|The proportion choosing A was six out of ten, or 60%.|6 de 10 respondentes: podemos dizer 60% de todos os moradores?|Não, só respondentes dessa amostra.|8 de 20 cartões são verdes. Expresse proporção e total.|The proportion of green cards is eight out of twenty, or 40%.
fraction|fração, parte de um todo|a fraction of the total|Only a small fraction of the archive was checked.|Small fraction não é porcentagem exata sem dados adicionais.|Texto diz a small fraction. Podemos inferir exatamente 5%?|Não.|3 de 12 páginas revisadas. Dê fração equivalente.|Three twelfths; one quarter.|Apenas 2 de 50 itens foram verificados. Redija sem afirmar que toda a coleção foi revisada.|Only a small fraction of the collection was checked: two out of fifty items.
double|dobrar ou ser duas vezes uma quantidade|double the number; the number doubled|The number doubled from ten to twenty.|Base precisa estar explícita; double não é aumento de 200%, e sim de 100%.|10 passa a 20: doubled ou tripled?|Doubled.|Número dobra de 15. Novo valor?|30.|Participantes passam de 24 a 48. Escreva mudança com double, informando base.|The number of participants doubled from twenty-four to forty-eight.
halve|reduzir à metade|halve the time; the time was halved|The waiting time was halved from twenty to ten minutes.|Metade do valor inicial, não diminuição de apenas duas unidades.|Espera 30 passa a 15 minutos. Use halve.|The waiting time was halved.|Custo fictício passa de 80 a 40. Foi reduzido à metade?|Sim.|Tempo de preparação vai de 12 a 6 horas. Descreva com halve.|Preparation time was halved from twelve to six hours.
average|média aritmética neste contexto|an average of; on average|The average of two, four and six is four.|Nesta sequência average é soma dividida pela quantidade; médias podem ocultar diferenças.|Tempos 2, 4 e 6 minutos. Qual média?|4 minutos.|Média 5: todos os valores necessariamente são 5?|Não.|Duas sessões duram 10 e 30 minutos. Relate média e variação observada.|The average was twenty minutes; the sessions lasted ten and thirty minutes.''',
('b2','time'): '''peak|atingir um ponto máximo ou esse máximo|peak at; reach a peak|Attendance peaked at forty in June.|Máximo no período fornecido, não recorde histórico universal.|Valores maio 20, junho 40, julho 30. Quando e em quanto peaked?|It peaked at forty in June.|Peak of 50 in this sample: recorde de todos os tempos?|Não.|Visitas segunda 12, terça 18, quarta 9. Descreva o pico do período.|Visits peaked at eighteen on Tuesday during this three-day period.
plateau|estabilizar após mudança|plateau at; reach a plateau|Attendance rose and then plateaued at thirty.|Poucos pontos sugerem estabilidade observada, não previsão garantida.|Valores 10, 20, 30, 30, 30. Descreva etapa final.|Attendance plateaued at thirty in the last three observations.|Plateaued this week: garante próxima semana igual?|Não.|Inscrições sobem de 15 a 25 e ficam em 25 por três dias. Resuma sem prever futuro.|Registrations rose to twenty-five and then plateaued for three days.
fluctuate|oscilar entre valores|fluctuate between X and Y|Attendance fluctuated between twenty and thirty.|Oscilação não é crescimento contínuo; informar período e unidades.|Valores 20, 30, 22, 28: rise steadily ou fluctuate?|Fluctuate.|Fluctuated between 5 and 9: valores seguiram sempre aumentando?|Não.|Tempos 8, 12, 9 e 11 minutos em quatro dias. Faça descrição.|The times fluctuated between eight and twelve minutes over four days.
steadily|de maneira contínua ou regular|increase steadily|The count increased steadily from ten to forty.|Não implica passos exatamente iguais em todo uso; comparar série real.|Valores 10, 20, 30, 40: descreva tendência com steadily.|The count increased steadily.|10, 20, 12, 25: steadily descreve bem essa série?|Não; houve queda intermediária.|Produção 5, 10, 15, 20 por semana. Redija tendência com período.|Weekly production increased steadily from five to twenty items.
roughly|aproximadamente, sem precisão exata|roughly half; roughly twenty|Roughly half of the chairs were occupied.|Roughly não informa margem formal de erro; não inventá-la.|Texto roughly half of 20. É contagem exata de dez?|Não; é aproximação.|Roughly 100: a palavra especifica intervalo 95–105?|Não.|Observador estimou cerca de 30 presentes sem contar. Redija e atribua fonte.|The observer estimated that roughly thirty people were present.
overall|considerando o conjunto|overall, + clause; an overall increase|Overall, attendance increased despite a fall in June.|Síntese pode coexistir com exceções locais; não apagá-las.|Série 10, 20, 15, 30. Descreva overall com ressalva.|Overall, attendance increased, although it fell at the third observation.|Overall improvement: garante melhora em cada item?|Não.|Dados janeiro 50, fevereiro 40, março 60. Faça síntese que preserve fevereiro.|Overall, the figure rose from fifty to sixty, despite a fall to forty in February.''',
('c1','numbers'): '''negligible|pequeno a ponto de ter pouca importância para um fim declarado|a negligible difference|For this rough layout, a one-millimetre difference is negligible.|Avaliação depende de escala e finalidade; não equivale a zero universal.|Editor diz diferença negligible para rascunho. Isso prova zero diferença?|Não; pequena para a finalidade declarada.|1 mm é negligible em qualquer uso?|Não; depende da exigência e contexto.|Para painel de 3 m, designer aceita diferença de 1 mm no esboço. Reformule sem universalizar.|The designer regards the one-millimetre difference as negligible for this preliminary layout.
substantial|considerável em magnitude ou importância|a substantial increase|The report describes the increase as substantial.|Termo avaliativo sem limiar numérico universal; atribuir julgamento.|Relatório diz substantial increase sem números. Podemos converter em 50%?|Não.|Reviewer calls a reduction substantial. Isso é mensuração exata?|Não; qualificação do revisor.|Custo fictício de impressão cai de 100 para 60; autora considera queda grande. Relate dado e julgamento.|Printing costs fell from one hundred to sixty, a reduction the author describes as substantial.
disproportionate|desproporcional a uma referência explicitada|disproportionate to; a disproportionate share|The time spent was disproportionate to the task’s scope.|A referência precisa estar clara; comparação quantitativa não prova injustiça por si só.|Revisor diz disproportionate effort. Qual dado falta para avaliar a comparação?|Referência de proporcionalidade: escopo, resultado ou outro critério relevante.|20% dos itens tomam 80% do tempo. Isso por si prova gestão injusta?|Não; complexidade e outros critérios podem explicar.|Dois itens simples recebem metade da reunião; autor compara com oito itens ainda não tratados. Expresse avaliação atribuída.|The chair considered the time devoted to the two simple items disproportionate to their scope; eight items remained undiscussed.
comparable|comparável em algum aspecto relevante|comparable in size; comparable to|The two rooms are comparable in size.|Comparable não significa idêntico em tudo; especificar dimensão.|Rooms comparable in size. Isso implica mesmo preço?|Não.|Resultados de grupos com métodos diferentes: basta dizer comparable para provar comparabilidade?|Não; é preciso justificar dimensões e condições comparadas.|Dois espaços têm 40 e 42 m², custos distintos. Descreva sem igualar custo e área.|The rooms are comparable in size, although their prices differ.
on the order of|na ordem de, magnitude aproximada|on the order of a thousand|The archive contains on the order of a thousand items.|Uso quantitativo aproximado; não é número exato nem ordem de execução.|On the order of a thousand: garante 1.000 exatamente?|Não.|Texto estima magnitude de milhares. Pode citar uma unidade exata inventada?|Não.|Catalogação parcial sugere cerca de 10 mil registros. Escreva com expressão e limitação.|The archive appears to contain on the order of ten thousand records, based on a partial catalogue.
within reach|ao alcance, viável diante de condições|within reach of; bring X within reach|The revised target is within reach if the final batch arrives.|Pode ser figurativo; viabilidade não é realização consumada.|Target within reach if delivery arrives. Meta já foi atingida?|Não; depende da condição.|Within reach descreve garantia absoluta de sucesso?|Não.|Faltam cinco inscrições para meta; prazo aberto. Redija como possibilidade, não promessa.|The target appears within reach, with five registrations still needed before the deadline.''',
('c1','time'): '''cumulative|que se acumula ao longo de ocorrências|a cumulative total; cumulative effect|The cumulative total reached sixty by Friday.|Total acumulado não é necessariamente valor de sexta isoladamente; evitar contagem dupla.|Segunda 10 novos, terça 15 novos. Cumulative total até terça?|25.|Total acumulado sexta 60: sexta sozinha teve 60?|Não.|Totais acumulados quarta 40, quinta 55. Quantos foram acrescentados e como relatar?|Fifteen were added on Thursday, bringing the cumulative total to fifty-five.
in due course|no momento oportuno, sem prazo exato especificado|respond in due course|The committee will respond in due course.|Pode soar formal ou evasivo; não transformar em data prometida.|Resposta in due course. Há data exata garantida?|Não.|Prazo urgente: essa expressão resolve necessidade de data?|Não; pedir um prazo mais específico.|Reformule promessa vaga em pedido cortês de data para organizar agenda.|You said a reply would follow in due course. Could you give us an expected date so we can plan?
for the time being|por enquanto, em caráter temporário|for the time being, + clause|For the time being, the library will use Room B.|Duração final não necessariamente definida; não supor permanência.|Uso Room B for the time being: solução permanente?|Não.|A expressão sozinha informa quando acaba?|Não.|Mudança provisória para sala 2 sem data de retorno. Redija aviso fiel.|For the time being, sessions will take place in Room 2; a return date has not been confirmed.
over the course of|ao longo de um período|over the course of the year|The policy changed over the course of the year.|Não exige mudança contínua nem informa instante exato.|Changed over the course of a year: ocorreu necessariamente todo dia?|Não.|A expressão localiza período ou data única?|Período.|Três ajustes distribuídos no semestre; redija sem sugerir alteração diária.|Three adjustments were made over the course of the semester.
subsequently|posteriormente, em sequência temporal|subsequently + verb|The draft was circulated and subsequently revised.|Sequência temporal não prova que a circulação causou a revisão.|A happened; subsequently B. Isso estabelece causa?|Não; apenas posterioridade.|Documento enviado dia 2, revisto dia 5. Qual evento é subsequent?|A revisão.|Houve consulta, depois mudança; causa não documentada. Redija com limite.|The consultation was followed by a revision; the document was subsequently changed, though the record does not establish why.
with hindsight|em retrospecto, com conhecimento adquirido depois|with hindsight, + clause|With hindsight, the deadline was unrealistic.|Distinguir julgamento atual do que participantes podiam saber antes.|Com dados posteriores, prazo parece curto. Já sabiam isso no início?|Não necessariamente.|With hindsight autoriza culpar quem não tinha os dados?|Não.|Plano original previa dez dias; depois descobriram tarefa adicional de cinco. Reavalie sem atribuir conhecimento retroativo.|With hindsight, the ten-day deadline was too tight, but the additional task was not known when it was set.'''
}
GROUPS = [{'level': 'pre-a1',
  'id': 'LEX-PRE-20',
  'title': 'Confirmar quantidades de onze a dezesseis',
  'after': 'FND-03',
  'words': ['eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen'],
  'situation': 'Recepção fictícia; quadro visível 11 eleven, 12 twelve, 13 thirteen, 14 fourteen, 15 '
               'fifteen, 16 sixteen. Cartão A: books 11, pens 14, cups 16. Cartão B tem caixas rotuladas '
               '11/12/13/14/15/16 e não vê a lista de A. A pede Eleven books, please; B repete Eleven? antes '
               'de separar cartão. Rodada invertida: books 13, pens 12, cups 15. Um pedido de confirmação '
               'deve ser introduzido em cada rodada; ninguém movimenta objetos reais pesados. Depois o '
               'destinatário escreve três quantidades sem copiar a lista do emissor.',
  'result': 'Primeira entrega books 11, pens 14, cups 16; segunda books 13, pens 12, cups 15. A repetição '
            'precisa manter a quantidade, não apenas nomear objeto. Se há apoio numérico, registrar produção '
            'apoiada. Números 1–6 não substituem 11–16.',
  'phon': 'Ouvir e restituir dois números por vez. O falante pode repetir ou mostrar algarismo depois da '
          'tentativa; registrar quando houve apoio visual. A compreensão pode ser verificada por escolha de '
          'etiqueta, sem exigir soletração.',
  'pitfall': 'Separar apresentação em dois conjuntos de três se necessário; não testar todas as formas antes '
             'de ensino. A pessoa pode usar cartão de quantidade: esta tarefa avalia comunicação, não '
             'cálculo mental.'},
 {'level': 'pre-a1',
  'id': 'LEX-PRE-21',
  'title': 'Distinguir dezessete a vinte e primeiras dezenas',
  'after': 'FND-05',
  'words': ['seventeen', 'eighteen', 'nineteen', 'twenty', 'thirty', 'forty'],
  'situation': 'Quadro: 17 seventeen, 18 eighteen, 19 nineteen, 20 twenty, 30 thirty, 40 forty. Pedido A: '
               'cups 17, pens 20, books 30. B recebe inventário com todas as etiquetas e deve repetir cada '
               'quantidade antes de marcar. B diz Thirteen? ao receber thirty; A usa No, thirty: 30 com '
               'apoio já aprendido. Inversão: cups 18, pens 19, books 40. Confira no final o inventário '
               'pedido versus separado, sem converter palavras em preço.',
  'result': 'Primeira: 17, 20, 30. Segunda: 18, 19, 40. Reparo distingue 13 de 30; consultar a sequência '
            'anterior para thirteen. Modelo: Thirty books, please. — Thirteen? — No, thirty. O objetivo é '
            'destinatário recuperar 30, não uma pronúncia idêntica à de locutor.',
  'phon': 'Compare thirteen/thirty e fourteen/forty em frases; mantenha audível final teen quando aplicável. '
          'Acento pode variar por ênfase, portanto usar confirmação e contexto, não regra absoluta de '
          'posição tônica.',
  'pitfall': 'Thirty não ensina automaticamente thirty-one etc. Compostos de dezenas e unidades devem ter '
             'apoio próprio antes de serem cobrados. Não inferir domínio de números apenas por recitar a '
             'lista em ordem.'},
 {'level': 'pre-a1',
  'id': 'LEX-PRE-22',
  'title': 'Confirmar dezenas de cinquenta a cem',
  'after': 'FND-06',
  'words': ['fifty', 'sixty', 'seventy', 'eighty', 'ninety', 'one hundred'],
  'situation': 'Quadro bilíngue: 50 fifty, 60 sixty, 70 seventy, 80 eighty, 90 ninety, 100 one hundred. A '
               'tem quantidade de cartões para três mesas: mesa 1 fifty; mesa 2 eighty; mesa 3 one hundred. '
               'B anota números sem ver a lista. Inverter: mesa 1 sixty, mesa 2 seventy, mesa 3 ninety. B '
               'precisa confirmar uma quantidade com Again, please. Ofereça etiquetas prontas de 15/50, '
               '18/80, 19/90 para etapa de discriminação com voz disponível. Sem áudio ou pessoa, usar '
               'leitura e anotar modalidade escrita.',
  'result': 'Rodada 1: 50, 80, 100; rodada 2: 60, 70, 90. A pessoa deve corrigir uma troca possível entre '
            'teen e ty; não exigir contar fisicamente cem objetos. Evidência auditiva só existe se a lista '
            'foi realmente ouvida sem leitura prévia.',
  'phon': 'Fifty/fifteen, eighty/eighteen e ninety/nineteen em contexto com unidade explícita. Mudar a ordem '
          'das etiquetas. Aceitar repetição mais lenta e confirmação por número escrito depois da primeira '
          'tentativa.',
  'pitfall': 'A expansão cobre dezenas exatas, não todo sistema de numeração. Não aplicar números a '
             'dosagens, transações reais ou dados pessoais. Avaliação usa as novas quantidades de cada '
             'entrada.'},
 {'level': 'a1',
  'id': 'LEX-A1-15',
  'title': 'Combinar atividades de janeiro a junho',
  'after': 'A1-08',
  'words': ['January', 'February', 'March', 'April', 'May', 'June'],
  'situation': 'Calendário fictício com seis meses e tradução. Cartão A: English class starts in January and '
               'ends in June; book club in March; room closed in May. Cartão B: art class in February; '
               'library visit in April; book club note says May. Apoios: starts = começa, ends = termina, '
               'closed = fechado. Troquem informação com When is the book club? / In March. Reparem a nota '
               'incorreta usando March, not May. O destinatário monta quadro mês/atividade e diferencia fim '
               'do curso de fechamento da sala.',
  'result': 'January início do curso; February aula de arte; March clube do livro; April visita; May sala '
            'fechada; June fim do curso. Não inferir que o curso para durante todo maio: falta informação '
            'sobre outro local. Pergunta aceitável: Is there another room in May?',
  'phon': 'Confirmar May/March e June quando o colega não entendeu. Datas permanecem apenas por mês, sem '
          'exigir ordinais ainda não ensinados. Pode haver leitura oral por pessoa de apoio; texto visto '
          'antes limita evidência de escuta.',
  'pitfall': 'Meses são rótulos culturais de calendário, não previsão de clima ou hábitos. Apresentar três '
             'meses por vez, reutilizar o quadro e registrar apoio. Não exigir datas de nascimento.'},
 {'level': 'a1',
  'id': 'LEX-A1-16',
  'title': 'Reparar uma agenda de julho a dezembro',
  'after': 'A1-08',
  'words': ['July', 'August', 'September', 'October', 'November', 'December'],
  'situation': 'A recebe: course starts in July; exhibition in September; course ends in November. B recebe: '
               'new room in August; class visit in October; library closed in December. Quadro traduz '
               'exhibition/exposição e os seis meses. Cada participante faz três perguntas When...?; depois '
               'verifica um recado que trocou July por June e October por November. Modelo I have July. Is '
               'that right? = Tenho julho. Está certo? Devolva uma agenda conjunta, preservando eventos '
               'diferentes que ocorrem em meses distintos.',
  'result': 'July início, August nova sala, September exposição, October visita, November fim do curso, '
            'December fechamento da biblioteca. Corrigir June para July; visita não é no mês de '
            'encerramento. Não completar datas exatas ausentes.',
  'phon': 'June/July, September/December e October/November em contexto de atividade. A restituição deve '
          'incluir evento e mês, não só repetir a última palavra ouvida.',
  'pitfall': 'Não associar automaticamente dezembro a férias ou a inverno. O quadro é consulta permitida '
             'durante aprendizagem; na avaliação registrar se foi usado. Integração com janeiro–junho pode '
             'ocorrer em outra sessão, sem apresentação de doze formas de uma só vez.'},
 {'level': 'a1',
  'id': 'LEX-A1-17',
  'title': 'Separar duração e horário em uma agenda',
  'after': 'A1-02',
  'words': ['minute', 'hour', 'day', 'week', 'month', 'year'],
  'situation': 'Cartão A: Call: starts at ten, lasts five minutes. Class: starts at two, lasts one hour. '
               'Visit: three days. Cartão B: Course: two weeks. Project: six months. Programme: one year. '
               'Apoios lasts = dura, programme = programa de estudo, at two = às duas. Perguntem How long? = '
               'Quanto tempo? e What time? = A que horas? Complete tabela com início e duração; quando não '
               'existe horário inicial, escreva not given = não informado. Compare one hour com at two para '
               'impedir troca de início e duração.',
  'result': 'Chamada início 10 h/duração 5 min; aula início 2 h/duração 1 h; visita 3 dias, curso 2 semanas, '
            'projeto 6 meses, programa 1 ano, sem horários iniciais informados. Não converter mês '
            'automaticamente em trinta dias nem deduzir datas finais sem calendário e início.',
  'phon': 'O ouvinte repete número e unidade: five MINUTES, one HOUR. Aceitar hour com h não pronunciado e '
          'an hour; corrigir apenas quando troca de unidade altera a informação.',
  'pitfall': 'Apoiar numerais com quadro. Não exigir cálculo de datas ou domínio gramatical de duração até o '
             'presente. O exemplo de year é um programa fictício, não relato biográfico.'},
 {'level': 'a2',
  'id': 'LEX-A2-15',
  'title': 'Ler uma rotina de frequências sem confundir duração',
  'after': 'A2-01',
  'words': ['once', 'twice', 'daily', 'weekly', 'monthly', 'every other day'],
  'situation': 'A tem calendário da biblioteca: doors checked daily; newsletter monthly; book club once a '
               'week, on Wednesday. B tem calendário de uma turma: lessons twice a week, Tuesday and '
               'Thursday; planning meeting weekly on Monday; short reading practice every other day starting '
               'Monday. Apoios doors checked = portas conferidas, newsletter = boletim. Monte uma semana '
               'segunda–domingo da leitura (segunda, quarta, sexta, domingo), separada dos encontros. '
               'Explique ao destinatário por que twice a week não significa curso de duas semanas. Uma '
               'pergunta How long is the course? não pode ser respondida pelos cartões.',
  'result': 'Portas diariamente; boletim mensal sem dia informado; clube uma vez quarta; aulas terça/quinta; '
            'planejamento segunda; leitura segunda/quarta/sexta/domingo. A duração total do curso não está '
            'declarada. Modelo: We have lessons twice a week, but the timetable does not say how long the '
            'course lasts.',
  'phon': 'Once/twice com unidade de frequência; contraste every day/every other day em duas frases '
          'completas. Não pontuar somente pronúncia da palavra solta. Registrar texto escrito versus voz '
          'usada.',
  'pitfall': 'Calendário serve de apoio; não cobrar aritmética mental nem rotina pessoal. Monthly não vira '
             'automaticamente a cada trinta dias. Atividades de revisão devem ocorrer em outra sessão com '
             'novo início.'},
 {'level': 'a2',
  'id': 'LEX-A2-16',
  'title': 'Conferir medidas e porções em listas',
  'after': 'A2-05',
  'words': ['litre', 'kilogram', 'metre', 'half', 'quarter', 'dozen'],
  'situation': 'Encontro fictício, só planejamento em papel. A tem lista: two litres of water; one kilogram '
               'of rice; a dozen cups. B tem sala: table two metres long; eight blue cards, half for each '
               'pair; twelve red cards, a quarter for the door sign. Apoios rice/arroz, sign/placa, cada par '
               'recebe metade dos oito azuis. Troquem quantidades e unidades. Um recado troca two litres of '
               'water por two metres of water: expliquem a correção. Calculadora ou cartões já divididos são '
               'permitidos; ninguém precisa cozinhar ou medir equipamento real.',
  'result': 'Água 2 L; arroz 1 kg; copos 12; mesa 2 m; cada par 4 azuis; placa 3 vermelhos. Modelo: We need '
            'two litres of water, not two metres. A quarter of the twelve red cards is three. Se numeracia '
            'bloquear, fornecer 4 e 3 e avaliar a frase com unidade/fração.',
  'phon': 'Recuperar número e unidade em conjunto. Aceitar litre/liter, metre/meter, kilo/kilogram. Apoio '
          'oral deve evitar que o aprendiz veja a lista reservada antes de ouvir.',
  'pitfall': 'Isto não é instrução nutricional nem receita. Half e quarter funcionam em outras construções a '
             'ensinar posteriormente; horários quarter past não são cobrados aqui.'},
 {'level': 'b1',
  'id': 'LEX-B1-15',
  'title': 'Informar estimativas, mínimos e limites',
  'after': 'B1-04',
  'words': ['estimate', 'approximately', 'at least', 'at most', 'up to', 'no more than'],
  'situation': 'Aviso A: Small workshop, room limit 20 participants; at least 12 registrations are needed to '
               'run it; 15 are confirmed; organiser estimates approximately 18 will attend. B: each '
               'participant may bring no more than 2 written examples; a draft advert says 20 confirmed. '
               'Produza anúncio corrigido de 60–90 palavras. Inclua limite, mínimo, confirmado, estimativa e '
               'restrição dos exemplos. Depois a mensagem nova registra 21 solicitações, ainda não '
               'confirmadas. Explique qual número precisa ser limitado segundo o cartão, sem inventar regra '
               'real de segurança ou decidir quem entra.',
  'result': 'Mínimo 12, limite 20, confirmado 15, estimativa 18; anúncio não pode declarar 20 confirmados. '
            'No more than two examples; at most twenty/up to twenty como limite. Com 21 pedidos há demanda '
            'maior que limite, não 21 presenças confirmadas. Modelo: We have fifteen confirmed registrations '
            'and estimate approximately eighteen attendees. The workshop needs at least twelve and can '
            'accept at most twenty.',
  'phon': 'Ênfase em AT LEAST versus AT MOST e valores; pedir ao ouvinte para restituir mínimo, máximo e '
          'confirmado. Apoio escrito dos números permanece disponível para que linguagem, não cálculo, seja '
          'o foco.',
  'pitfall': 'Não transformar estimativa em intervalo probabilístico formal. At most e no more than podem '
             'expressar o mesmo limite aqui, mas contraste de uso e registro continua contextual. A decisão '
             'de admissão não é feita pela atividade.'},
 {'level': 'b1',
  'id': 'LEX-B1-16',
  'title': 'Reorganizar compromissos e relatar o que aconteceu',
  'after': 'B1-05',
  'words': ['postpone', 'bring forward', 'run late', 'in the meantime', 'eventually', 'overtime'],
  'situation': 'Thread fictícia. A: Tuesday meeting moved to Thursday; Friday review moved to Wednesday of '
               'the same week. The delivery is running thirty minutes late. B: team can prepare labels while '
               'waiting; after two calls the delivery eventually arrives; two colleagues worked one hour '
               'beyond their normal schedule, with no pay information. Escreva atualização de 90–120 '
               'palavras com linha do tempo e separe revisão antecipada de reunião adiada. O destinatário '
               'pergunta se atraso cancelou entrega e se overtime foi pago; responda apenas com os '
               'registros. Suporte de datas ordinais se o estudante preferir datas numéricas.',
  'result': 'Meeting postponed Tuesday→Thursday; review brought forward Friday→Wednesday; atraso 30 min; '
            'etiquetas enquanto esperam; entrega por fim após 2 chamadas; duas pessoas com 1 hora extra '
            'cada, remuneração desconhecida. Não somar e chamar two hours overtime por pessoa. Aceitar '
            'paráfrases naturais e observar cada expressão separadamente.',
  'phon': 'Contrastar forward/postponed com data original e nova; ouvinte recompõe ordem. Eventually é '
          'resultado posterior, não frequência ocasional. Pausas devem separar estado de espera da '
          'conclusão.',
  'pitfall': 'Não presumir legislação, obrigação ou pagamento de hora extra. Objetivo é relato linguístico '
             'fictício. Se há dificuldade com sequência, oferecer cartões ordenáveis antes da produção, '
             'registrando apoio.'},
 {'level': 'b2',
  'id': 'LEX-B2-17',
  'title': 'Comparar razões, proporções e médias com base explícita',
  'after': 'B2-06',
  'words': ['ratio', 'proportion', 'fraction', 'double', 'halve', 'average'],
  'situation': 'Dois conjuntos independentes de dados fictícios. A: workshop cards, 12 blue and 6 red; '
               'visitors yesterday 24/today 48. B: two queues lasted 10/30 min; a procedure changed from 20 '
               'to 10 min; only 3 of 12 archived pages were checked. Redija explicação de 100–140 palavras '
               'para leitor geral, usando blue:red ratio, share of checked pages, doubled visitors, halved '
               'procedure time and mean queue time. Forneça cálculo como apoio: 12:6=2:1;3/12=1/4; '
               'média(10+30)/2=20. Depois responda se média 20 implica que ambas filas duraram 20 e se 12:6 '
               'é proporção de azuis no total.',
  'result': 'Razão azul:vermelho de 2:1; proporção de azuis no total de 12/18, ou dois terços. Visitantes '
            'dobram de 24 para 48; tempo do procedimento cai à metade, de 20 para 10 minutos. Média das duas '
            'filas de 20 minutos, com observações de 10 e 30; um quarto das páginas foi verificado. Apenas '
            'esses dados fundamentam o relato. Se o cálculo for fornecido, avaliar a explicação linguística, '
            'não habilidade matemática.',
  'phon': 'Pronunciar two to one, one quarter e from twenty to ten dentro de frases. O parceiro registra '
          'base e unidade. Pergunta de confirmação deve focalizar denominador ou ordem da razão.',
  'pitfall': 'Average está definido como média aritmética, não toda medida de tendência central. Dobrar '
             'equivale a aumento de 100% sobre base inicial; não converter em 200% de aumento. Não inferir '
             'causa ou representatividade.'},
 {'level': 'b2',
  'id': 'LEX-B2-18',
  'title': 'Descrever tendências sem apagar oscilações',
  'after': 'B2-06',
  'words': ['peak', 'plateau', 'fluctuate', 'steadily', 'roughly', 'overall'],
  'situation': 'Cartão A: six weekly visits, W 1=10,W 2=20,W 3=30,W 4=30,W 5=25,W 6=40. Cartão B: four '
               'session lengths=8,12,9,11 minutes; observer estimates roughly 30 people at another event, '
               'not counted. Produza legenda de gráfico e resumo oral ou escrito. Aumento inicial regular, '
               'breve estabilidade, queda e pico devem coexistir na síntese overall. Não misture visitantes '
               'com minutos nem a estimativa de outro evento. Pergunta inédita do destinatário: Will next '
               'week reach 50? Responda com limite da fonte.',
  'result': 'Semanas 1–3: crescimento regular; semanas 3–4: breve estabilidade em 30; semana 5: queda para '
            '25; semana 6: pico de 40 no período. No conjunto, aumento de 10 para 40 com queda '
            'intermediária. Durações das sessões oscilam entre 8 e 12 minutos; roughly thirty se refere a '
            'outro evento e continua sendo estimativa. Não há base para prever 50 na semana seguinte. '
            'Modelo: Overall, visits increased, though the pattern was not steady throughout the six weeks.',
  'phon': 'Pausas entre tendência geral e ressalva; enfatizar despite/although se usados. Destinatário deve '
          'identificar semana do pico e reconhecer incerteza da estimativa, não apenas repetir verbos.',
  'pitfall': 'Não exigir desenho visual: tabela textual equivalente. Plateau de dois pontos é descrição '
             'breve, não estado permanente. Evitar jargão estatístico sem suporte e manter escopo da '
             'amostra.'},
 {'level': 'c1',
  'id': 'LEX-C1-11',
  'title': 'Qualificar magnitudes e viabilidade conforme o propósito',
  'after': 'B2-06',
  'words': ['negligible', 'substantial', 'disproportionate', 'comparable', 'on the order of', 'within reach'],
  'situation': 'Editorial note A: two proposed reading rooms measure 40/42 m²; rent differs; preliminary '
               'shelf sketch has 1 mm variation accepted by designer; incomplete catalogue suggests around '
               '1000 titles. Note B: printing estimate fell 100→60 units, which editor calls substantial; '
               'chair thinks half a meeting on two minor items is disproportionate while eight remain; '
               'registration target 50, confirmed 45, deadline still open. Write a 140–180-word briefing to '
               'a general audience. Attribute judgements, distinguish size comparison from price, and '
               'qualify reachable target without promising it. Recipient challenges the phrase negligible: '
               'explain the purpose-bound judgement and what another use would require.',
  'result': 'As salas são comparáveis apenas em área; os custos diferem. A variação de 1 mm é insignificante '
            'para aquele esboço segundo o designer. Cerca de mil títulos é estimativa baseada em catalogação '
            'parcial. O custo de impressão cai de 100 para 60, redução de 40% que a editora chama de '
            'substantial. A desproporção do tempo é julgamento do coordenador; atingir a meta depende de '
            'cinco inscrições adicionais. Não atribuir limiares universais aos adjetivos. Aceitar paráfrases '
            'naturais e registrar quais expressões-alvo foram efetivamente usadas.',
  'phon': 'Discourse stress and pause before attribution and qualification. Listener should separate source '
          'measurement from editorial judgement; intelligibility and precision matter more than accent '
          'matching.',
  'pitfall': 'Não exigir formação estatística; fornecer comparações prontas. Nenhuma opinião sobre custo ou '
             'proporção tem validade universal. Não converter adjetivo avaliativo em diagnóstico ou decisão '
             'de elegibilidade.'},
 {'level': 'c1',
  'id': 'LEX-C1-12',
  'title': 'Reconstituir um processo preservando tempo e conhecimento disponível',
  'after': 'B2-03',
  'words': ['cumulative',
            'in due course',
            'for the time being',
            'over the course of',
            'subsequently',
            'with hindsight'],
  'situation': 'Case record: Monday cumulative registrations 10; Tuesday 25; Wednesday 40. A committee '
               'message promises a reply in due course, no date. Room B is temporary for the time being, '
               'return date unknown. Three revisions occur over the course of a semester; consultation '
               'precedes second revision, causal link undocumented. Original ten-day deadline was set before '
               'an extra five-day task became known. Write a 160–200-word account and a separate '
               'three-sentence request for a useful response date. Recipient asks whether Wednesday added 40 '
               'new people and whether original planners knew the extra task; answer explicitly with '
               'evidence boundaries.',
  'result': 'Os totais acumulados mostram 15 novas inscrições na terça e outras 15 na quarta. Não há data '
            'para resposta nem para retorno à sala original. As três revisões se distribuem pelo semestre; '
            'subsequently estabelece ordem temporal, não causa. With hindsight permite reavaliar o prazo sem '
            'afirmar que os responsáveis já conheciam a tarefa adicional. O pedido deve solicitar uma data '
            'esperada com cortesia. Modelo: With hindsight, the original deadline was too tight; the '
            'additional task, however, was not known when it was set.',
  'phon': 'Agrupar cronologia em blocos e contrastar then/now, total/new, provisional/confirmed. O ouvinte '
          'reconstrói o que era conhecido em cada momento, com texto de apoio se necessário.',
  'pitfall': 'Registro formal pode ser adaptado ao destinatário; não obrigar todas as expressões num único '
             'parágrafo artificial. Avaliar precisão temporal, informação ausente e adequação da '
             'solicitação; não usar contagem de conectivos como rubrica de C 1.'}]
